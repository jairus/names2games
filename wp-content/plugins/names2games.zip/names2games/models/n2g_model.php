<?php
class n2g_model{
	function __construct(){
	}
}
?>